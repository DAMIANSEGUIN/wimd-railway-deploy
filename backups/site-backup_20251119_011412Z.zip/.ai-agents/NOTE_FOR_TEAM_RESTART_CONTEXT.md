# Quick Note — Restart Context Bundle

When restarting the Codex CLI session, share the checklist in `docs/CODEX_RESTART_CONTEXT_CHECKLIST.md`. Paste the requested information (git status/log, deployment baseline, verification snapshot, current objective, evidence links) into the first message so Codex can resume work immediately without re-triaging.
