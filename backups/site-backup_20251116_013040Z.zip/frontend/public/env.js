// Environment configuration - currently disabled for testing
// To enable Supabase features, uncomment and configure:
/*
window.__ENV = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-KEY"
};
*/

// For now, app runs in localStorage-only mode
console.log('Running in localStorage-only mode - Supabase features disabled');