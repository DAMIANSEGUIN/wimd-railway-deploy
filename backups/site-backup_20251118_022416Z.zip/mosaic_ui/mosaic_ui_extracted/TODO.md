# TODO.md
- Wire `askCoach()` to `/wimd` in production.
- Decide on SurveyMonkey; set `SURVEY_URL` or keep JSON-only feedback.
- Merge demo into production `index.html` / `styles.css` / `app.js`.
- Add second connector path for Discovery → Modules (SVG).
- Refine microcopy after first beta wave.
