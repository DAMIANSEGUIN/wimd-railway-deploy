# Mosaic — Delivery Bundle (ASK window failing) — 20250915_153142

## Deployment Info
- **Production URL:** https://whatismydelta.com
- **Staging URL:** (not detected in backups)
- **Backend Base URL:** unknown
- **Health Check Routes:** `/api/ask/health` or `/health`
- **ASK Endpoint:** `/api/ask` or `/ask`

## Live Status
- ASK window: ❌ failing
- UI present: ✅
- API reachable: Unknown
- CSV: Unknown
- LLM call: Skipped

## BLOCKERS
- BLOCKER-SEC-APIKEYS: UNKNOWN
- BLOCKER-DATA-PROMPTS: UNKNOWN
- BLOCKER-API-BACKEND: UNKNOWN
- BLOCKER-UI-ASK: FAIL

## Decision Matrix
See `decision_matrix.csv` for details.
